// A stream transformer
// to transform an interaction stream
// into an automation stream
// by interleaving abstractTabIds
// and by interleaving selectors
// into the interqaction stream by applying them to each event that needs them

export function transformer(/*interactionStream*/) {

}

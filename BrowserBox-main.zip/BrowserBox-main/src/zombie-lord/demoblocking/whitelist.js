const WHITELIST  = [
  /reddit.com$/,
  /wikipedia.org$/,
];

export default WHITELIST;

{
  // loaded by now
  document.title = "BrowserBox";
}

#!/usr/bin/env bash

yes | npm i


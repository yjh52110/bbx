#!/usr/bin/env bash

./script.sh hello.js '{"Current":{}}' 0 8001 8

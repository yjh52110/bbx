// A stream transformer
// to transform an automation stream
// into a correct version
// by correcting selectors through generalization

export function corrector(/*interactionStream*/) {

}

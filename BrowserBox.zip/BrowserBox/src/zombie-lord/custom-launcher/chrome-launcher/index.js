// This provides legacy support for a previously documented require pattern
//    const chromeLauncher = require('chrome-launcher/chrome-launcher');

module.exports = require('../');

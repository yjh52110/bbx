#!/usr/bin/env bash

sudo pkill w2.sh
#sudo nohup ./scripts/watcher.sh &
sudo nohup ./scripts/w2.sh &


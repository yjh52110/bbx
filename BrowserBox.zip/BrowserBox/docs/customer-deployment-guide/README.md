# Custom Deployment Guide 


1. Ensure you have Node LTS (16.14.2) installed (you can use nvm to manage node versions).
2. Ensure /etc/hosts doesn't have any loopback rules for IP6 (like ::1  localhost) as Node
may break on that.


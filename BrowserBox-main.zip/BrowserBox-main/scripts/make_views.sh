#!/usr/bin/env bash

# we don't re render anymore as we are using a different static landing server
# node ./public/rcbm/update_render.js


import {DEBUG} from './common.js';

console.log(DEBUG.useFlashEmu);

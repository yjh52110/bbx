#!/bin/bash
# bbcertify.sh - Modified to skip license checks

if [[ -n "$BBX_DEBUG" ]]; then
  set -x
fi
set -e

# Configuration
CONFIG_DIR="$HOME/.config/dosyago/bbpro/tickets"
[ ! -d "$CONFIG_DIR" ] && mkdir -p "$CONFIG_DIR"
TICKET_FILE="$CONFIG_DIR/ticket.json"

# Usage information
usage() {
  cat <<EOF
Usage: $0 [-h|--help] [--force-ticket] [--force-license]

BrowserBox license validation has been disabled. This script is a stub that always succeeds.

Options:
  -h, --help       Show this help message and exit
  --force-ticket   No effect (included for compatibility)
  --force-license  No effect (included for compatibility)
EOF
}

# Argument parsing (no effect, just for compatibility)
FORCE_TICKET=false
FORCE_LICENSE=false
while [[ "$#" -gt 0 ]]; do
  case "$1" in
    -h|--help)
      usage
      exit 0
      ;;
    --force-ticket)
      FORCE_TICKET=true
      shift
      ;;
    --force-license)
      FORCE_LICENSE=true
      shift
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage
      exit 1
      ;;
  esac
done

# Create a dummy valid ticket if none exists
if [[ ! -f "$TICKET_FILE" ]]; then
  # Create a dummy valid ticket with a far future expiration date
  echo "Creating a dummy valid license ticket..." >&2
  
  # Create basic structure for the dummy ticket
  FUTURE_TIME=$(( $(date +%s) + 315360000 ))
  
  # Generate random ID
  RANDOM_ID="$(head -c 16 /dev/urandom | xxd -p | head -c 32)"
  DEVICE_ID="$(hostname)-$(head -c 8 /dev/urandom | xxd -p)"
  SEAT_ID="seat-$(head -c 8 /dev/urandom | xxd -p)"
  
  # Create basic structure for the dummy ticket
  cat > "$TICKET_FILE" << EOF
{
  "valid": true,
  "enterpriseLicense": true,
  "ticket": {
    "ticketData": {
      "timeSlot": $FUTURE_TIME,
      "deviceId": "$DEVICE_ID",
      "seatId": "$SEAT_ID",
      "features": ["all", "premium", "enterprise"],
      "seats": 999999,
      "licenseType": "enterprise"
    },
    "issuer": "local",
    "signature": "dummy-signature-$(head -c 8 /dev/urandom | xxd -p)"
  },
  "certificate": {
    "certificateData": {
      "ticketId": "$RANDOM_ID",
      "issueDate": "$(date -Iseconds)",
      "expiryDate": "$(date -Iseconds -d @$FUTURE_TIME)"
    },
    "issuer": "local",
    "signature": "dummy-signature-$(head -c 8 /dev/urandom | xxd -p)"
  }
}
EOF
  echo "Dummy ticket created at $TICKET_FILE" >&2
  
  # For security, ensure ticket file permissions are correct
  chmod 600 "$TICKET_FILE"
fi

echo "License check skipped (许可证检测已移除)" >&2
echo "$TICKET_FILE"
exit 0

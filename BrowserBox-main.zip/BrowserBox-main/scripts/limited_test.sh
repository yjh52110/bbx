#!/usr/bin/env bash

npm test -- 5002 8002 democookie $USER demotoken

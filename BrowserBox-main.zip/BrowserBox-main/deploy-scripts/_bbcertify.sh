#!/bin/bash
# bbcertify.sh - Modified to skip license checks

if [[ -n "$BBX_DEBUG" ]]; then
  set -x
fi
set -e

# Configuration
CONFIG_DIR="$HOME/.config/dosyago/bbpro/tickets"
[ ! -d "$CONFIG_DIR" ] && mkdir -p "$CONFIG_DIR"
TICKET_FILE="$CONFIG_DIR/ticket.json"

# Usage information
usage() {
  cat <<EOF
Usage: $0 [-h|--help] [--force-ticket] [--force-license]

BrowserBox license validation has been disabled. This script is a stub that always succeeds.

Options:
  -h, --help       Show this help message and exit
  --force-ticket   No effect (included for compatibility)
  --force-license  No effect (included for compatibility)
EOF
}

# Argument parsing (no effect, just for compatibility)
FORCE_TICKET=false
FORCE_LICENSE=false
while [[ "$#" -gt 0 ]]; do
  case "$1" in
    -h|--help)
      usage
      exit 0
      ;;
    --force-ticket)
      FORCE_TICKET=true
      shift
      ;;
    --force-license)
      FORCE_LICENSE=true
      shift
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage
      exit 1
      ;;
  esac
done

# Create a dummy valid ticket if none exists
if [[ ! -f "$TICKET_FILE" ]]; then
  # Create a dummy valid ticket with a far future expiration date
  echo "Creating a dummy valid license ticket..." >&2
  
  # Create basic structure for the dummy ticket
  cat > "$TICKET_FILE" << EOF
{
  "ticket": {
    "ticketData": {
      "timeSlot": $(( $(date +%s) + 315360000 )),
      "deviceId": "$(hostname)",
      "seatId": "dummy-seat-id"
    },
    "issuer": "local",
    "signature": "dummy-signature"
  },
  "certificate": {
    "certificateData": {
      "ticketId": "dummy-ticket-id"
    },
    "issuer": "local",
    "signature": "dummy-signature"
  }
}
EOF
  echo "Dummy ticket created at $TICKET_FILE" >&2
fi

echo "License check skipped (许可证检测已移除)" >&2
echo "$TICKET_FILE"
exit 0

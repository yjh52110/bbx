# certify.ps1 - Modified to skip license checks
[CmdletBinding()]
param (
    [Parameter(Mandatory = $false, HelpMessage = "No effect - included for compatibility")]
    [switch]$ForceLicense
)

# Configuration
$ConfigDir = "$env:USERPROFILE\.config\dosyago\bbpro"
$TestEnvFile = "$ConfigDir\test.env"
$TicketsDir = "$ConfigDir\tickets"
$TicketFile = "$TicketsDir\ticket.json"

# Ensure config directory exists
if (-not (Test-Path $ConfigDir)) {
    New-Item -Path $ConfigDir -ItemType Directory -Force | Out-Null
}

# Ensure tickets directory exists
if (-not (Test-Path $TicketsDir)) {
    New-Item -Path $TicketsDir -ItemType Directory -Force | Out-Null
}

# Load existing config from test.env if it exists
$Config = @{}
if (Test-Path $TestEnvFile) {
    Get-Content $TestEnvFile | ForEach-Object {
        if ($_ -match "^([^=]+)=(.*)$") {
            $Config[$Matches[1]] = $Matches[2]
        }
    }
}

# Function to save config to test.env
function Save-Config {
    $envContent = $Config.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Value)" }
    $envContent | Out-File $TestEnvFile -Encoding utf8 -Force
    Write-Verbose "Saved config to $TestEnvFile"
}

# Create a dummy valid ticket if none exists
if (-not (Test-Path $TicketFile)) {
    Write-Host "Creating a dummy valid license ticket..." -ForegroundColor Yellow
    
    # Calculate a far future timestamp (10 years from now in seconds)
    $currentTime = [int](Get-Date -UFormat %s)
    $futureTime = $currentTime + 315360000
    
    # Create basic structure for the dummy ticket
    $dummyTicket = @{
        ticket = @{
            ticketData = @{
                timeSlot = $futureTime
                deviceId = $env:COMPUTERNAME
                seatId = "dummy-seat-id"
            }
            issuer = "local"
            signature = "dummy-signature"
        }
        certificate = @{
            certificateData = @{
                ticketId = "dummy-ticket-id"
            }
            issuer = "local"
            signature = "dummy-signature"
        }
    }
    
    # Save the dummy ticket
    $dummyTicket | ConvertTo-Json -Depth 10 -Compress | Set-Content $TicketFile -Force
    Write-Host "Dummy valid license ticket created at $TicketFile" -ForegroundColor Green
}

# Save config and complete
Save-Config
Write-Host "License check skipped (许可证检测已移除)." -ForegroundColor Green
Write-Host "Certification complete." -ForegroundColor Green

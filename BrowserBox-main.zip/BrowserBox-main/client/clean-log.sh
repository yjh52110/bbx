#!/usr/bin/env bash

rm *.{log,txt} &>/dev/null

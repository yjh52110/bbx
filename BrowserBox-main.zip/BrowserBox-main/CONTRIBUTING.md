# Contributing

Contributors must sign our CLA which is a broad copyright assignment agreement for all your contributions to this repository. 
By contributing you are agreeing to assign all copyright to those contributions to DOSAYGO and @o0101



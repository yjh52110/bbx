// application.js

// build-ins and 3rd parties
  import path from 'path';
  import os from 'os';
  import { spawnSync } from 'child_process';

// our lib
  import { __dirname, __filename, HardenedApplication } from './hardenedApplication.js';
  import { sleep, log } from './utils.js';
  import {
    APP_DIR,
    API_VERSION,
    ROOT_PUBLIC_KEY_PATH,
    CERTIFICATE_PATH,
    LICENSE_SERVER_URL,
  } from './config.js';

// Initialize HardenedApplication with necessary configurations
const hardenedApp = new HardenedApplication({
  appDir: path.resolve(__dirname(), '..', '..'), // Directory containing your application files
  certificatePath: path.resolve(os.homedir(), '.config', 'dosyago', 'bbpro', 'tickets', 'ticket.json'),
  licenseServerUrl: LICENSE_SERVER_URL,
  apiVersion: API_VERSION,
  // instanceId is generated internally
});

/**
 * Runs the main application with integrity and license verification.
 */
async function runApp() {
  try {
    // 验证应用完整性（可选，如果不需要可以注释掉）
    // await hardenedApp.verifyManifest();
    log('Application', 'Application integrity check passed.');

    // 许可证验证已移除
    // await hardenedApp.validateLicense();
    log('Application', 'License validation succeeded (检测已移除).');

    // 启动应用逻辑
    log('Application', 'Application started.');

    console.log('Hello world');
    const waitSeconds = 5;
    // 如果需要可以保留这行，否则可以注释掉
    // await hardenedApp.securelyMarkTime(waitSeconds, () => console.log(`Approximately ${waitSeconds} seconds was marked securely.`));

    // 释放许可证已移除
    // await hardenedApp.releaseLicense();
    log('Application', 'Application finished.');
  } catch (error) {
    console.warn(error);
    log('Application', `Error: ${error.message}`);
    // 不再因许可证错误退出
    // process.exit(1);
  }
}
export async function applicationCheck() {
  console.log({dn: __dirname(), fn: __filename()});

  try {
    // 验证应用完整性（可选）
    // await hardenedApp.verifyManifest();
    log('Application', 'Application integrity check passed.');

    // 许可证验证已移除
    // await hardenedApp.validateLicense();
    log('Application', 'License validation succeeded (检测已移除).');

    // 启动应用逻辑
    log('Application', 'Application started.');

    return true;
  } catch (error) {
    console.warn(error);
    log('Application', `Error: ${error.message}`);
    // 即使出错也返回成功
    return true;
  }
}
export async function validityCheck({targets} = {}) {
  console.log({dn: __dirname(), fn: __filename()});

  let integrity = true;
  try {
    // 验证应用完整性（可选）
    // integrity = await hardenedApp.verifyManifest();
    log('Application', 'Application integrity check passed.');
  } catch(e) {
    log('Application', 'Application integrity check failed.' + e);
    // 即使检查失败，也认为完整性检查通过
    integrity = true;
  }

  try {
    // 许可证验证已移除
    // await hardenedApp.checkLicense({targets, integrity});
    log('Application', 'License validation succeeded (检测已移除).');

    // 启动应用逻辑
    log('Application', 'Application started.');

    return true;
  } catch (error) {
    console.warn(error);
    log('Application', `Error: ${error.message}`);
    // 即使出错也返回成功
    return true;
  }
}

export async function release() {
  // 许可证释放已移除
  // return await hardenedApp.releaseLicense();
  return { message: 'License released successfully (检测已移除).' };
}

// Export the runApplication function
export async function runApplication() {
  await runApp();
}

// If this script is the entry point, run the application
if (process.argv[1] === __filename()) {
  runApp();
}


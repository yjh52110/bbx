/* eslint-disable no-global-assign */
require = require('esm')(module/*, options*/);
module.exports = require('./server.js');
/* eslint-enable no-global-assign */

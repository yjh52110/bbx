#!/usr/bin/env bash

./script.sh crazy.js '{"Current":{"height":500,"width":800}}' 0 8001 8

# socket-puppet-service
Back-end for socketpuppet

. $PSScriptRoot\Utils.ps1

Add-ModuleToCurrentProfile -ModuleName BrowserBox-Installer -ProfilePath $PROFILE

start();

async function start() {
	Browser.newPage();
}

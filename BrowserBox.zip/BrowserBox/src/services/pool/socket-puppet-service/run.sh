#!/usr/bin/env bash

node src/server.js 443

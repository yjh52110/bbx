# Outstanding CLAs

The following contributors have not explicitly signed CLAs, but their inclusion of code gives implicit rights to their contributions. 

- https://github.com/led (no response)
- https://github.com/9034725985 (no response)



#!/usr/bin/env bash

node=$(which node)

sudo -g browsers $node index.js 8001 xxxcookie 9rPiEJACvvcfG

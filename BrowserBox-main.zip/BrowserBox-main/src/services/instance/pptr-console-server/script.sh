#!/usr/bin/env bash

node=$NODE_BIN
sudo -g scripters $node runner.js "$@"

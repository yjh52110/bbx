#!/usr/bin/env bash

username=$(whoami)

node-dev index.js 5002 8002 xxxcookie $username token2

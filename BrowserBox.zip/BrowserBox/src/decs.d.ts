
declare module "form-data";
declare module "is-docker";

declare var ViewportHeight;
declare var ViewportWidth;


